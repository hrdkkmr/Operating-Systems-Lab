struct stat;
struct rtcdate;

// system calls
int fork(void);
int exit(void) __attribute__((noreturn));
int wait(void);
int pipe(int*);
int write(int, const void*, int);
int read(int, void*, int);
int close(int);
int kill(int);
int exec(char*, char**);
int open(const char*, int);
int mknod(const char*, short, short);
int unlink(const char*);
int fstat(int fd, struct stat*);
int link(const char*, const char*);
int mkdir(const char*);
int chdir(const char*);
int dup(int);
int getpid(void);
char* sbrk(int);
int sleep(int);
int uptime(void);
void* shm_get(void);
// Lab 7
int clone(void(*fcn)(void*), void *arg, void *stack);
int join(void);
int sem_init(int sem_id, int value);
int sem_wait(int sem_id);
int sem_signal(int sem_id);
int set_priority(int pid, int priority);
int get_priority(int pid);
int vmprint(void);      // Lab 9 Q1: print own page table, return #valid user pages
int getfaults(void);    // Lab 9 Q2: lazy page faults handled for this process

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
void printf(int, const char*, ...);
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
void* malloc(uint);
void free(void*);
int atoi(const char*);
